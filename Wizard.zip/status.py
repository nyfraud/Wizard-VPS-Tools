import subprocess
import requests
import time

# Discord webhook URL
WEBHOOK_URL = "https://discord.com/api/webhooks/"

# Interval for checking server status (in seconds)
CHECK_INTERVAL = 300  # Every 5 minutes

def get_server_status():
    try:
        # Use a system command to check server status
        output = subprocess.check_output(["uptime"]).decode("utf-8").strip()
        return output
    except Exception as e:
        print(f"Error checking server status: {e}")
        return None

def send_discord_notification(message):
    payload = {
        "content": message
    }
    try:
        response = requests.post(WEBHOOK_URL, json=payload)
        if response.status_code == 200:
            print("Notification sent successfully")
        else:
            print(f"Failed to send notification: HTTP {response.status_code}")
    except Exception as e:
        print(f"Error sending notification: {e}")

def watch_server_status():
    previous_status = None
    while True:
        current_status = get_server_status()
        if current_status is not None and current_status != previous_status:
            # Server status has changed, send notification
            send_discord_notification(f"Server Status: {current_status}")
            previous_status = current_status
        time.sleep(CHECK_INTERVAL)

if __name__ == "__main__":
    watch_server_status()
