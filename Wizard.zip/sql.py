import subprocess
import requests
import time

# MySQL database details
DB_HOST = 'localhost'
DB_USER = ''
DB_PASSWORD = ''
DB_NAME = ''

# Discord webhook URL
WEBHOOK_URL = 'https://discord.com/api/webhooks/'

# Backup file name
BACKUP_FILE = 'backup.sql'

def backup_and_send():
    # MySQL dump command
    dump_command = f"mysqldump -u {DB_USER} -p{DB_PASSWORD} -h {DB_HOST} {DB_NAME} > {BACKUP_FILE}"

    # Execute MySQL dump command
    subprocess.run(dump_command, shell=True)

    # Send backup file to Discord webhook
    with open(BACKUP_FILE, 'rb') as f:
        files = {'file': f}
        requests.post(WEBHOOK_URL, files=files)

    # Clean up backup file
    subprocess.run(f"rm {BACKUP_FILE}", shell=True)
# Schedule backup_and_send function to run every 60 minutes
        time.sleep(15000)  # Wait for 30 seconds before checking again

if __name__ == "__main__":
    main()
