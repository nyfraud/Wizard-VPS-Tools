import os
import subprocess

# Define your commands here
commands = {
    "1": {"name": "Wizard File", "command": "screen python3 wizard.py"},
    "2": {"name": "Wizard Alert", "command": "screen python3 alert.py"},
    "3": {"name": "Wizard SQL", "command": "screen python3 sql.py"},
    "4": {"name": "Wizard Status", "command": "screen python3 status.py"},
    "5": {"name": "Coming Soon", "command": ""},
    "6": {"name": "Coming Soon", "command": ""},  # Change this path
    "7": {"name": "Exit", "command": "exit"}
}

def show_commands():
    """Displays the list of available commands."""
    print("\nWizard Menu Commands:")
    for key, value in commands.items():
        print(f"{key}. {value['name']}")

def run_command(choice):
    """Executes the selected command."""
    if choice in commands:
        if choice == "7":
            print("Exiting program.")
            exit()
        
        command = commands[choice]["command"]
        print(f"\nRunning: {command}\n")
        process = subprocess.run(command, shell=True)
        
        if process.returncode != 0:
            print(f"Error: Command `{command}` failed.")
    else:
        print("Invalid choice. Please select a valid option.")

def main():
    """Main loop to display and run commands."""
    while True:
        show_commands()
        choice = input("\nEnter the number of the command to run: ").strip()
        run_command(choice)

if __name__ == "__main__":
    main()